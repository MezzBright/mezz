
        const API_URL = "https://fedskillstest.coalitiontechnologies.workers.dev";

        class PatientDashboard {
            constructor() {
                this.init();
            }

            async init() {
                try {
                    const data = await this.fetchPatientData();
                    this.processPatientData(data);
                } catch (error) {
                    console.error("Dashboard initialization failed:", error);
                    this.showErrorToUser("Failed to load patient data. Please try again later.");
                }
            }

            async fetchPatientData() {
                const response = await fetch(API_URL, {
                    method: 'GET',
                    headers: {
                        'Authorization': 'Basic Y29hbGl0aW9uOnNraWxscy10ZXN0'
                    }
                });

                if (!response.ok) {
                    throw new Error(`API request failed with status ${response.status}`);
                }

                return await response.json();
            }

            processPatientData(data) {
                if (!Array.isArray(data)) {
                    throw new Error("Expected array of patients but received invalid data format");
                }

                const jessica = data.find(patient => 
                    patient.name && patient.name.toLowerCase().includes("jessica taylor")
                );

                if (!jessica) {
                    throw new Error("Jessica Taylor not found in patient data");
                }

                this.updatePatientProfile(jessica);
                
                if (this.hasValidBloodPressureData(jessica)) {
                    this.renderBloodPressureChart(jessica);
                } else {
                    this.showWarningToUser("No valid blood pressure data available for display");
                }
            }

            hasValidBloodPressureData(patient) {
                return patient.bloodPressure && 
                       Array.isArray(patient.bloodPressure) && 
                       patient.bloodPressure.length > 0 &&
                       patient.bloodPressure.every(entry => 
                           entry.year !== undefined && entry.value !== undefined
                       );
            }

            updatePatientProfile(patient) {
                const setTextContent = (id, text) => {
                    const element = document.getElementById(id);
                    if (element) element.textContent = text;
                };

                setTextContent("patient-name", patient.name || "N/A");
                setTextContent("patient-dob", patient.date_of_birth || "N/A");
                setTextContent("patient-gender", patient.gender || "N/A");
                setTextContent("patient-phone", patient.phone_number || "N/A");
                setTextContent("patient-emergency", patient.emergency_contact || "N/A");
                
                if (patient.picture) {
                    const imgElement = document.getElementById("patient-avatar");
                    if (imgElement) {
                        imgElement.src = patient.picture;
                        imgElement.style.display = "block";
                    }
                }
            }

            renderBloodPressureChart(patient) {
                try {
                    const ctx = document.getElementById("bpChart");
                    if (!ctx) throw new Error("Chart canvas element not found");

                    const labels = patient.bloodPressure.map(entry => entry.month || "N/A");
                    const systolicValues = patient.bloodPressure.map(entry => entry.systolic?.value || 0);
                    const diastolicValues = patient.bloodPressure.map(entry => entry.diastolic?.value || 0);

                    new Chart(ctx.getContext("2d"), {
                        type: "line",
                        data: {
                            labels,
                            datasets: [
                                {
                                    label: "Systolic",
                                    data: systolicValues,
                                    borderColor: "#6b21a8",
                                    backgroundColor: "rgba(107, 33, 168, 0.2)",
                                    borderWidth: 2,
                                    fill: false,
                                    tension: 0.3
                                },
                                {
                                    label: "Diastolic",
                                    data: diastolicValues,
                                    borderColor: "#db2777",
                                    backgroundColor: "rgba(219, 39, 119, 0.2)",
                                    borderWidth: 2,
                                    fill: false,
                                    tension: 0.3
                                }
                            ]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                title: {
                                    display: true,
                                    text: 'Blood Pressure Over Time',
                                    font: { size: 16 }
                                },
                                legend: { position: 'top' }
                            },
                            scales: {
                                y: {
                                    beginAtZero: false,
                                    title: { display: true, text: 'mmHg' }
                                },
                                x: {
                                    title: { display: true, text: 'Month' }
                                }
                            }
                        }
                    });
                } catch (error) {
                    console.error("Failed to render blood pressure chart:", error);
                    this.showWarningToUser("Could not display blood pressure chart");
                }
            }

            showErrorToUser(message) {
                this.showMessageToUser(message, "error");
            }

            showWarningToUser(message) {
                this.showMessageToUser(message, "warning");
            }

            showMessageToUser(message, type) {
                const existingMessage = document.getElementById("user-message");
                if (existingMessage) existingMessage.remove();

                const messageElement = document.createElement("div");
                messageElement.id = "user-message";
                messageElement.style.padding = "1rem";
                messageElement.style.margin = "1rem 0";
                messageElement.style.borderRadius = "4px";
                
                if (type === "error") {
                    messageElement.style.backgroundColor = "#f8d7da";
                    messageElement.style.color = "#721c24";
                    messageElement.style.border = "1px solid #f5c6cb";
                } else {
                    messageElement.style.backgroundColor = "#fff3cd";
                    messageElement.style.color = "#856404";
                    messageElement.style.border = "1px solid #ffeeba";
                }

                messageElement.textContent = message;
                document.body.prepend(messageElement);
            }
        }

        document.addEventListener('DOMContentLoaded', () => {
            new PatientDashboard();
        });
    